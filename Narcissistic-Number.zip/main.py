def narcissistic( value ):
  number=str(value)
  digits=len(number)
  sum=0
  for i in range(0,digits):
    x=int(number[i])**digits
    sum=sum+x
  if value==sum:
    return True
  else:
    return False